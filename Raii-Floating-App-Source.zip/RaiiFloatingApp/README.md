# Raii Floating App

Independent Android utility app starter built from scratch. It does not contain the original app's activation code, backend, or proprietary assets.

## Included
- Android WebView dashboard with Browser, Translate, Gallery, and Draw tools.
- Native movable floating bubble using Android overlay permission.
- Dark-first interface and theme toggle.
- No account, activation key, or license server.

## Build
1. Install Android Studio (with Android SDK 35) and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK on an Android device.

The first time you enable the bubble, Android opens the special "Display over other apps" permission page. Grant it, return to the app, and tap the bubble button again.

## Notes
- Browser and Translate hand off to the device browser / Google Translate.
- Gallery uses Android's file chooser.
- Draw is a local canvas with PNG export.
- Floating bubble opens the app when tapped and can be dragged around the screen.
