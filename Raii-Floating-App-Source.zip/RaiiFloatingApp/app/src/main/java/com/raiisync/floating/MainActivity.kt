package com.raiisync.floating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AppBridge(), "RaiiNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    inner class AppBridge {
        @JavascriptInterface fun startBubble() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(i)
                    Toast.makeText(this@MainActivity, "Izinkan tampil di atas aplikasi lain, lalu tekan Bubble lagi", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, FloatingBubbleService::class.java))
                    Toast.makeText(this@MainActivity, "Bubble aktif", Toast.LENGTH_SHORT).show()
                }
            }
        }
        @JavascriptInterface fun stopBubble() {
            runOnUiThread { stopService(Intent(this@MainActivity, FloatingBubbleService::class.java)) }
        }
        @JavascriptInterface fun openUrl(url: String) {
            runOnUiThread {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                    .onFailure { Toast.makeText(this@MainActivity, "Tidak bisa membuka tautan", Toast.LENGTH_SHORT).show() }
            }
        }
    }
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
